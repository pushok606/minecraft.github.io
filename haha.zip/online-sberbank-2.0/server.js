const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const port = 3000;

const db = new sqlite3.Database(':memory:');

db.serialize(() => {
    db.run("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, nickname TEXT UNIQUE, balance REAL)");
    const stmt = db.prepare("INSERT INTO users (nickname, balance) VALUES (?, ?)");
    stmt.run("user1", 100.00);
    stmt.run("user2", 100.00);
    stmt.finalize();
});

app.use(bodyParser.json());

app.get('/balance/:nickname', (req, res) => {
    const { nickname } = req.params;
    db.get("SELECT balance FROM users WHERE nickname = ?", [nickname], (err, row) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(row || { balance: 0 });
    });
});

app.post('/transfer', (req, res) => {
    const { from, to, amount } = req.body;
    if (amount <= 0) {
        return res.status(400).json({ error: "Amount must be positive" });
    }
    
    db.serialize(() => {
        db.get("SELECT balance FROM users WHERE nickname = ?", [from], (err, row) => {
            if (err || !row) {
                res.status(500).json({ error: err ? err.message : "Sender not found" });
                return;
            }
            
            const senderBalance = row.balance;
            if (senderBalance < amount) {
                return res.status(400).json({ error: "Insufficient funds" });
            }
            
            db.run("UPDATE users SET balance = balance - ? WHERE nickname = ?", [amount, from], function(err) {
                if (err) {
                    res.status(500).json({ error: err.message });
                    return;
                }
                
                db.run("UPDATE users SET balance = balance + ? WHERE nickname = ?", [amount, to], function(err) {
                    if (err) {
                        res.status(500).json({ error: err.message });
                        return;
                    }
                    
                    res.json({ success: true });
                });
            });
        });
    });
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
